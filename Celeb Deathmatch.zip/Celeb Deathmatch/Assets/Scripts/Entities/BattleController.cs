﻿using UnityEngine;
using System.Collections;

public class BattleController : MonoBehaviour {
	public int roundTime = 100;
	private float lastTimeUpdate = 0;
	private bool battleStarted;
	private bool battleEnded;

	public Fighter player1;



	// Use this for initialization
	void Start () {
	}


	
	// Update is called once per frame
	void Update () {
		if (!battleStarted) {
			battleStarted = true;

			player1.enable = true;

		}

		if (battleStarted && !battleEnded) {
			if (roundTime > 0 && Time.time - lastTimeUpdate > 1) {
				roundTime--;
				lastTimeUpdate = Time.time;
				if (roundTime == 0){
                    player1.healt = 0;
                }
            }

			if (player1.healtPercent <= 0) {
				battleEnded = true;

			} 
		}
	}
}
