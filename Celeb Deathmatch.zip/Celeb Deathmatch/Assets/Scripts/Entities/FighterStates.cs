﻿using UnityEngine;
using System.Collections;

public enum FighterStates  {
	IDLE, WALK, WALK_BACK, JUMP, DUCK,
	ATTACK, TAKE_HIT, TAKE_HIT_DEFEND, 
	DEFEND, CELEBRATE, DEAD, NONE
}
